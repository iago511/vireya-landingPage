function irCadastro(){
    window.location.href = "cadastro.html";
}